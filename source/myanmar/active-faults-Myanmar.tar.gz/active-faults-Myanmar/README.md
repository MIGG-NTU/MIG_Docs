# Active faults in Myanmar from EOS

- faults: faults dataset
- plot-faults.pl: perl scripts used to plot the faults
    - faults-Myanmar.png: an example figure


## References

- Wang, Y., Sieh, K., Tun, S. T., Lai, K. Y., & Myint, T. (2014). Active tectonics and earthquake potential of the Myanmar region. Journal of Geophysical Research: Solid Earth, 119(4), 3767-3822.
